# Total War: Warhammer III — Sub-Faction Crests

54 sub-faction crests scraped from totalwarwarhammer.fandom.com.

## Format
- 256×256 PNG with alpha channel (RGBA)
- Originally served as WebP by Fandom; converted to true PNG via Pillow

## Structure
```
crests/
├── manifest.json          # full mapping race → sub-faction → file
├── Kislev/
│   ├── the_ice_court.png
│   ├── the_great_orthodoxy.png
│   └── ursun_revivalists.png
├── Grand_Cathay/
│   └── ...
└── ...
```

## Source
All crests are property of Games Workshop / Creative Assembly.
Use within fair-use limits (fan tools, internal use).

## Notes on naming
- Yuan Bo's faction is **The Jade Court** (the user's original list was correct;
  "The Celestial Court" doesn't exist on the wiki).
- Epidemius's faction is **Tallymen of Pestilence** (not "of Nurgle").
- Orion's Wood Elf faction is **Argwylon** (Talsyn is actually Drycha's faction,
  but TWW uses "Wargrove of Woe" for Drycha — Talsyn-named faction doesn't exist
  as a playable LL sub-faction in the wiki taxonomy).
- Count Noctilus's Vampire Coast faction is **The Drowned** (not "The Dreadfleet").
- Helman Ghorst's faction is **Caravan of Blue Roses** (the user's list said
  "Vampire Counts" which is the race name, not the sub-faction name).
